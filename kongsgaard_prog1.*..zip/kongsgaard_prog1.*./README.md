I designed my finite automata to have all possible states. 
Beacuse this was so much code wrote my automata into different files named graphs. But they are all connected and they are the same finite automata.

To compile:

g++ -std=c++11 PasswordAutomata.h Graph1.h Graph2.h Graph3.h Graph4.h Graph5.h Graph6.h Graph7.h Graph8.h Graph9.h Graph10.h Graph11.h Graph12.h Graph13.h Graph14.h Graph15.h Graph16.h Graph17.h Graph18.h Graph19.h  PasswordAutomata.cpp Graph1.cpp Graph2.cpp Graph3.cpp Graph4.cpp Graph5.cpp Graph6.cpp Graph7.cpp Graph8.cpp Graph9.cpp Graph10.cpp Graph11.cpp Graph12.cpp Graph13.cpp Graph14.cpp Graph15.cpp Graph16.cpp Graph17.cpp Graph18.cpp Graph19.cpp
