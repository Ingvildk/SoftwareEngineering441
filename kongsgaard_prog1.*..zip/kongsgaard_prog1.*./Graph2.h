#ifndef _GRAPH2_H
#define _GRAPH2_H

#include <string>
#include <iostream>
#include "Graph2.h"
#include "Graph3.h"
#include "Graph4.h"
#include "Graph5.h"
#include "Graph6.h"
#include "Graph7.h"
#include "Graph8.h"
#include "Graph9.h"
#include "Graph10.h"
#include "Graph11.h"
#include "Graph12.h"
#include "Graph13.h"
#include "Graph14.h"
#include "Graph15.h"
#include "Graph16.h"
#include "Graph17.h"
#include "Graph18.h"
#include "Graph19.h"

using namespace std;

class Graph2 {
	public:
		void q0(string input);
		void q1(string input);
		void q2(string input);
		void q3(string input);
		void q4(string input);
};
#endif	